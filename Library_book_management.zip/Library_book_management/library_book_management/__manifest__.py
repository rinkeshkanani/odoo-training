{
    'name': "library_management",

    'summary': "Short (1 phrase/line) summary of the module's purpose",

    'description': """
Long description of module's purpose
    """,

    'author': "My Company",
    'website': "https://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/15.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','mail'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
		'security/group_library.xml',
		'security/rule_library.xml',
        'reports/library_borrow_report.xml',
        'reports/library_borrow_report_template.xml',
        'views/library_model_view.xml',
        'views/library_member_view.xml',
        'views/library_borrow_view.xml',
        'data/late_book.xml',
        'data/sequence_borrow.xml',
        'data/email_book.xml',
],
    'installable': True,
    'auto_install': False,

}

